// Wrapper client untuk ChatMessages + handle aksi bot
// "use client" karena ada handler done/snooze yang hit API

"use client"

import { useRouter } from "next/navigation"
import { Message } from "@prisma/client"
import ChatMessages from "./ChatMessages"

type Props = {
  messages: Message[]
}

export default function ChatContainer({ messages }: Props) {
  const router = useRouter()

  async function handleBotDone(botMessageId: string, sourceMessageId: string) {
    // tandai bot message sebagai done
    await fetch(`/api/messages/${botMessageId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isRemindDone: true }),
    })
    // tandai pesan asli sebagai done juga
    await fetch(`/api/messages/${sourceMessageId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isDone: true, isRemindDone: true }),
    })
    router.refresh()
  }

  async function handleBotSnooze(botMessageId: string) {
    // TODO: tampilkan snooze modal (15 menit, 1 jam, besok)
    // untuk sekarang tunda 1 jam dulu
    const snoozeTime = new Date(Date.now() + 60 * 60 * 1000)
    await fetch(`/api/messages/${botMessageId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ remindSnoozeAt: snoozeTime.toISOString() }),
    })
    router.refresh()
  }

  return (
    <ChatMessages
      messages={messages}
      onBotDone={handleBotDone}
      onBotSnooze={handleBotSnooze}
    />
  )
}