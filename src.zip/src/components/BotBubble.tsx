// Bubble + card reminder dari sistem
// Muncul saat reminder triggered — bubble teks di atas, card detail di bawah
// Tidak perlu "use client" untuk tampilan, interaksi di BotBubbleWrapper

import { Message } from "@prisma/client"
import { FiBell } from "react-icons/fi"

type Props = {
  message: Message
  sourceMessage?: Message | null
  onDone: () => void
  onSnooze: () => void
}

export default function BotBubble({ message, sourceMessage, onDone, onSnooze }: Props) {
  const time = new Date(message.createdAt).toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
  })

  return (
    <div className="flex flex-col items-start gap-1 my-2">

      {/* bubble teks bot — kiri */}
      <div className="flex items-end gap-2">
        {/* avatar bot */}
        <div
          className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mb-1"
          style={{ background: "var(--surface2)", border: "1px solid var(--border2)" }}
        >
          <FiBell size={14} style={{ color: "var(--accent)" }} />
        </div>

        {/* bubble */}
        <div
          className="rounded-[18px_18px_18px_4px] px-4 py-2.5 max-w-[75%]"
          style={{ background: "var(--surface2)", border: "1px solid var(--border2)" }}
        >
          <p className="text-sm" style={{ color: "var(--text)" }}>
            Hei! Kamu punya pengingat yang perlu diperhatikan 🔔
          </p>
        </div>
      </div>

      {/* card reminder */}
      <div
        className="ml-10 rounded-2xl p-4 w-full max-w-[75%]"
        style={{ background: "var(--surface2)", border: "1px solid var(--border2)" }}
      >
        {/* header card */}
        <div className="flex items-center gap-3 mb-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: "var(--accent)" }}
          >
            <FiBell size={18} style={{ color: "var(--bg)" }} />
          </div>
          <div>
            <p className="text-xs font-semibold font-sora" style={{ color: "var(--accent)" }}>
              Pengingat Terjadwal
            </p>
            {/* preview pesan asli */}
            <p className="text-sm mt-0.5 leading-relaxed" style={{ color: "var(--text)" }}>
              {sourceMessage?.text ?? message.text}
            </p>
          </div>
        </div>

        {/* dua tombol */}
        <div className="flex items-center gap-2 mt-1">
          <button
            onClick={onDone}
            className="px-4 py-2 rounded-xl text-sm font-semibold font-sora transition-opacity hover:opacity-90"
            style={{ background: "var(--accent)", color: "var(--bg)" }}
          >
            Selesai
          </button>
          <button
            onClick={onSnooze}
            className="px-4 py-2 rounded-xl text-sm font-semibold font-sora transition-opacity hover:opacity-90"
            style={{
              background: "var(--surface3)",
              color: "var(--text)",
              border: "1px solid var(--border2)"
            }}
          >
            Tunda
          </button>
        </div>
      </div>

      {/* timestamp */}
      <p className="ml-10 text-[10px] tabular-nums" style={{ color: "var(--text3)" }}>
        {time}
      </p>

    </div>
  )
}