import { auth } from "@/auth"
import { redirect, notFound } from "next/navigation"
import { prisma } from "@/lib/prisma"
import ChatHeader from "@/components/ChatHeader"
import ChatContainer from "@/components/ChatContainer"
import ChatInput from "@/components/ChatInput"

type Props = {
  params: Promise<{ id: string }>
}

export default async function RoomPage({ params }: Props) {
  const { id } = await params
  const session = await auth()
  if (!session?.user) redirect("/login")

  const room = await prisma.room.findFirst({
    where: { id, userId: session.user.id! },
  })
  if (!room) notFound()

  // cek reminder yang sudah waktunya — buat bot message kalau ada
  const pendingReminders = await prisma.message.findMany({
    where: {
      roomId: id,
      isBot: false,
      isRemindDone: false,
      remindAt: { lte: new Date() },
      // pastiin belum ada bot message untuk reminder ini
      reminders: { none: {} }
    }
  })

  // buat bot message untuk setiap reminder yang waktunya sudah tiba
  if (pendingReminders.length > 0) {
    await prisma.message.createMany({
      data: pendingReminders.map(reminder => ({
        text: "Hei! Kamu punya pengingat yang perlu diperhatikan 🔔",
        isBot: true,
        sourceMessageId: reminder.id,
        roomId: id,
        userId: session.user.id!,
      }))
    })
  }

  const messages = await prisma.message.findMany({
    where: { roomId: id },
    orderBy: { createdAt: "asc" },
  })

  const pendingCount = messages.filter(m => !m.isDone && !m.isBot).length

  return (
    <div className="flex flex-col h-full" style={{ background: "var(--bg)" }}>
      <ChatHeader
        name={room.name}
        icon={room.icon}
        messageCount={messages.filter(m => !m.isBot).length}
        pendingCount={pendingCount}
      />
      <ChatContainer messages={messages} />
      <ChatInput roomId={id} />
    </div>
  )
}